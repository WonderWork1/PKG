#!/usr/bin/env python

# ...

from distutils.core import setup

setup(name='cryptography-qpython',
      version='43.0.1',
      description='Cryptography is a package which provides cryptographic recipes and primitives to Python developers.',
      author='The Cryptography Development Team',
      author_email='support@qpython.org',
      url='https://pypi.org/project/cryptography /',
      packages=["cryptography"],
      package_data={
            "cryptography":[
"__about__.py",
"__init__.py",
"exceptions.py",
"fernet.py",
"hazmat/*",
"hazmat/backends/*",
"hazmat/backends/openssl/*",
"hazmat/bindings/*",
"hazmat/bindings/_rust/*",
"hazmat/bindings/_rust/openssl/*",
"hazmat/bindings/openssl/*",
"hazmat/decrepit/*",
"hazmat/decrepit/ciphers/*",
"hazmat/primitives/*",
"hazmat/primitives/asymmetric/*",
"hazmat/primitives/ciphers/*",
"hazmat/primitives/kdf/*",
"hazmat/primitives/serialization/*",
"hazmat/primitives/twofactor/*",
"py.typed",
"utils.py",
"x509/*",
]
      },
      long_description="""
cryptography is a package which provides cryptographic recipes and primitives to Python developers. Our goal is for it to be your “cryptographic standard library”. It supports Python 3.7+ and PyPy3 7.3.11+.
""",
      license="BSD",
      install_requires=["maturin-qpython"],
     )
